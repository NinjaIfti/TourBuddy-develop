<?php

namespace App\Services;

class TestService
{
    public function getTestHuman()
    {
        return "Test human returned from TestService";
    }
}
