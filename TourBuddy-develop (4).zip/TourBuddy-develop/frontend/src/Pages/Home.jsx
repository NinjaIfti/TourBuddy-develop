import "react";

const Home = () => {
  return (
    <div>
      <h1>Welcome to the Home Page</h1>
      <p>This is the homepage of your website.</p>
    </div>
  );
};

export default Home;
